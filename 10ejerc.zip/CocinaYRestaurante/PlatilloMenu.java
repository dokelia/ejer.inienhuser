/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CocinaYRestaurante;

/**
 *
 * @author ingeb
 */
public abstract class PlatilloMenu implements IEmpacableTermico {
    private String idPlato;
    private String nombre;
    private double precioBase;

    public PlatilloMenu() {
    }

    public PlatilloMenu(String idPlato, String nombre, double precioBase) {
        this.idPlato = idPlato;
        this.nombre = nombre;
        this.precioBase = precioBase;
    }

    public String getIdPlato() {
        return idPlato;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecioBase() {
        return precioBase;
    }

    public void setIdPlato(String idPlato) {
        this.idPlato = idPlato;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecioBase(double precioBase) {
        this.precioBase = precioBase;
    }

    @Override
    public String toString() {
        return "PlatilloMenu{" + "idPlato=" + idPlato + ", nombre=" + nombre + ", precioBase=" + precioBase + '}';
    }
    
    public void calcularPrecioFinal(){}
    
    public void prepararPlato(){}
    
}
