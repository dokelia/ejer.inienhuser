/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SangreYConservacion;

/**
 *
 * @author ingeb
 */
public class UltracongeladorNitrogeno {
    private double nivelNitrogenoPorcentaje;
    private double temperaturaCelsius;

    public UltracongeladorNitrogeno() {
    }

    public UltracongeladorNitrogeno(double nivelNitrogenoPorcentaje, double temperaturaCelsius) {
        this.nivelNitrogenoPorcentaje = nivelNitrogenoPorcentaje;
        this.temperaturaCelsius = temperaturaCelsius;
    }

    public void setNivelNitrogenoPorcentaje(double nivelNitrogenoPorcentaje) {
        this.nivelNitrogenoPorcentaje = nivelNitrogenoPorcentaje;
    }

    public void setTemperaturaCelsius(double temperaturaCelsius) {
        this.temperaturaCelsius = temperaturaCelsius;
    }

    public double getNivelNitrogenoPorcentaje() {
        return nivelNitrogenoPorcentaje;
    }

    public double getTemperaturaCelsius() {
        return temperaturaCelsius;
    }

    @Override
    public String toString() {
        return "UltracongeladorNitrogeno{" + "nivelNitrogenoPorcentaje=" + nivelNitrogenoPorcentaje + ", temperaturaCelsius=" + temperaturaCelsius + '}';
    }
    
    public void recargarNitrogenoLiquido(){}
}
