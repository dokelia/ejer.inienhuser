/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SangreYConservacion;

/**
 *
 * @author ingeb
 */
public class OrganoTrasplante extends UnidadBiologica{
    private String tipoOrgano;

    public OrganoTrasplante() {
    }

    public OrganoTrasplante(String tipoOrgano, String codigoDonacion, String grupoSanguineo, char factorRh) {
        super(codigoDonacion, grupoSanguineo, factorRh);
        this.tipoOrgano = tipoOrgano;
    }

    public void setTipoOrgano(String tipoOrgano) {
        this.tipoOrgano = tipoOrgano;
    }

    public String getTipoOrgano() {
        return tipoOrgano;
    }

    @Override
    public String toString() {
        return "OrganoTrasplante{" + "tipoOrgano=" + tipoOrgano + '}';
    }
    
    @Override
    public double monitorearTemperaturaContinua() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void registrarPuntoControlGPS(String nodo) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int calcularVidaUtilHoras() {
        return super.calcularVidaUtilHoras(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    
}
