/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SangreYConservacion;

/**
 *
 * @author ingeb
 */
public abstract class UnidadBiologica implements ITrazableCadenaFrio{
    private String codigoDonacion;
    private String grupoSanguineo;
    private char factorRh;

    public UnidadBiologica() {
    }

    public UnidadBiologica(String codigoDonacion, String grupoSanguineo, char factorRh) {
        this.codigoDonacion = codigoDonacion;
        this.grupoSanguineo = grupoSanguineo;
        this.factorRh = factorRh;
    }

    public void setCodigoDonacion(String codigoDonacion) {
        this.codigoDonacion = codigoDonacion;
    }

    public void setGrupoSanguineo(String grupoSanguineo) {
        this.grupoSanguineo = grupoSanguineo;
    }

    public void setFactorRh(char factorRh) {
        this.factorRh = factorRh;
    }

    public String getCodigoDonacion() {
        return codigoDonacion;
    }

    public String getGrupoSanguineo() {
        return grupoSanguineo;
    }

    public char getFactorRh() {
        return factorRh;
    }

    @Override
    public String toString() {
        return "UnidadBiologica{" + "codigoDonacion=" + codigoDonacion + ", grupoSanguineo=" + grupoSanguineo + ", factorRh=" + factorRh + '}';
    }
    
    public int calcularVidaUtilHoras(){
        return 0;
    }
    
    public boolean verificarCompatibilidad(String receptorTipo){
        return false;
    }
}
