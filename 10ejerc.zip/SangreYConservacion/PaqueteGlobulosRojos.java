/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SangreYConservacion;

/**
 *
 * @author ingeb
 */
public class PaqueteGlobulosRojos extends UnidadBiologica{
    private int volumenMililitros;
    private double hematocritoPorcentaje;

    public PaqueteGlobulosRojos() {
    }

    public PaqueteGlobulosRojos(int volumenMililitros, double hematocritoPorcentaje, String codigoDonacion, String grupoSanguineo, char factorRh) {
        super(codigoDonacion, grupoSanguineo, factorRh);
        this.volumenMililitros = volumenMililitros;
        this.hematocritoPorcentaje = hematocritoPorcentaje;
    }

    public void setVolumenMililitros(int volumenMililitros) {
        this.volumenMililitros = volumenMililitros;
    }

    public void setHematocritoPorcentaje(double hematocritoPorcentaje) {
        this.hematocritoPorcentaje = hematocritoPorcentaje;
    }

    public int getVolumenMililitros() {
        return volumenMililitros;
    }

    public double getHematocritoPorcentaje() {
        return hematocritoPorcentaje;
    }

    @Override
    public String toString() {
        return "PaqueteGlobulosRojos{" + "volumenMililitros=" + volumenMililitros + ", hematocritoPorcentaje=" + hematocritoPorcentaje + '}';
    }
    
    @Override
    public double monitorearTemperaturaContinua() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void registrarPuntoControlGPS(String nodo) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int calcularVidaUtilHoras() {
        return super.calcularVidaUtilHoras(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    public void centrifugarUnidad(){}
}
