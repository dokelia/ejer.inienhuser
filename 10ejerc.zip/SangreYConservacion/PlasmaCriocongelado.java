/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SangreYConservacion;

/**
 *
 * @author ingeb
 */
public class PlasmaCriocongelado extends UnidadBiologica {
    private int tiempoDescongelamientoMin;
    private UltracongeladorNitrogeno congeladorNitrogeno;

    public PlasmaCriocongelado() {
    }

    public PlasmaCriocongelado(int tiempoDescongelamientoMin, UltracongeladorNitrogeno congeladorNitrogeno, String codigoDonacion, String grupoSanguineo, char factorRh) {
        super(codigoDonacion, grupoSanguineo, factorRh);
        this.tiempoDescongelamientoMin = tiempoDescongelamientoMin;
        this.congeladorNitrogeno = congeladorNitrogeno;
    }

    public void setTiempoDescongelamientoMin(int tiempoDescongelamientoMin) {
        this.tiempoDescongelamientoMin = tiempoDescongelamientoMin;
    }

    public void setCongeladorNitrogeno(UltracongeladorNitrogeno congeladorNitrogeno) {
        this.congeladorNitrogeno = congeladorNitrogeno;
    }

    public int getTiempoDescongelamientoMin() {
        return tiempoDescongelamientoMin;
    }

    public UltracongeladorNitrogeno getCongeladorNitrogeno() {
        return congeladorNitrogeno;
    }

    @Override
    public String toString() {
        return "PlasmaCriocongelado{" + "tiempoDescongelamientoMin=" + tiempoDescongelamientoMin + ", congeladorNitrogeno=" + congeladorNitrogeno + '}';
    }
    
    @Override
    public double monitorearTemperaturaContinua() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void registrarPuntoControlGPS(String nodo) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int calcularVidaUtilHoras() {
        return super.calcularVidaUtilHoras(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    public void iniciarDescongeladoControlado(){}
}
