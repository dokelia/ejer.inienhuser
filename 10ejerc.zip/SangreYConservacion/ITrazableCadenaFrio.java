/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package SangreYConservacion;

/**
 *
 * @author ingeb
 */
public interface ITrazableCadenaFrio {
    double monitorearTemperaturaContinua();
    void registrarPuntoControlGPS(String nodo);
}
