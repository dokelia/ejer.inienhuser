/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogisticaYMaquinaria;

/**
 *
 * @author ingeb
 */
public abstract class MaquinariaPortuaria implements IPesableCertificado {
    private String idMaquinaria;
    private double capacidadCargaToneladas;
    private double combustibleLitros;

    public MaquinariaPortuaria() {
    }

    public MaquinariaPortuaria(String idMaquinaria, double capacidadCargaToneladas, double combustibleLitros) {
        this.idMaquinaria = idMaquinaria;
        this.capacidadCargaToneladas = capacidadCargaToneladas;
        this.combustibleLitros = combustibleLitros;
    }

    public void setIdMaquinaria(String idMaquinaria) {
        this.idMaquinaria = idMaquinaria;
    }

    public void setCapacidadCargaToneladas(double capacidadCargaToneladas) {
        this.capacidadCargaToneladas = capacidadCargaToneladas;
    }

    public void setCombustibleLitros(double combustibleLitros) {
        this.combustibleLitros = combustibleLitros;
    }

    public String getIdMaquinaria() {
        return idMaquinaria;
    }

    public double getCapacidadCargaToneladas() {
        return capacidadCargaToneladas;
    }

    public double getCombustibleLitros() {
        return combustibleLitros;
    }

    @Override
    public String toString() {
        return "MaquinariaPortuaria{" + "idMaquinaria=" + idMaquinaria + ", capacidadCargaToneladas=" + capacidadCargaToneladas + ", combustibleLitros=" + combustibleLitros + '}';
    }
    
    public void operarTurno (int horas){}
    public boolean inspeccionarFrenosSeguridad(){
        return false;
    }
}
