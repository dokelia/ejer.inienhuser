/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogisticaYMaquinaria;

/**
 *
 * @author ingeb
 */
public class GruaPorticoMuelle extends MaquinariaPortuaria{ 
    private double alturaElevacionMetros;
    private CabinaOperadorLaser cabinaLaser;

    public GruaPorticoMuelle() {
    }

    public GruaPorticoMuelle(double alturaElevacionMetros, CabinaOperadorLaser cabinaLaser, String idMaquinaria, double capacidadCargaToneladas, double combustibleLitros) {
        super(idMaquinaria, capacidadCargaToneladas, combustibleLitros);
        this.alturaElevacionMetros = alturaElevacionMetros;
        this.cabinaLaser = cabinaLaser;
    }

    public void setAlturaElevacionMetros(double alturaElevacionMetros) {
        this.alturaElevacionMetros = alturaElevacionMetros;
    }

    public void setCabinaLaser(CabinaOperadorLaser cabinaLaser) {
        this.cabinaLaser = cabinaLaser;
    }

    public double getAlturaElevacionMetros() {
        return alturaElevacionMetros;
    }

    public CabinaOperadorLaser getCabinaLaser() {
        return cabinaLaser;
    }

    @Override
    public String toString() {
        return "GruaPorticoMuelle{" + "alturaElevacionMetros=" + alturaElevacionMetros + ", cabinaLaser=" + cabinaLaser + '}';
    }
    
    @Override
    public double CertificarPesoVGM() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String generarTicketTara() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
     public void desembarcarBuque(){}
}
   
    
   




    
   


   

