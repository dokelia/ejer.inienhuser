/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogisticaYMaquinaria;

/**
 *
 * @author ingeb
 */
public class GruaApiladoraPatio extends MaquinariaPortuaria {
    private int nivelesApilamientoMax;

    public GruaApiladoraPatio() {
    }

    public GruaApiladoraPatio(int nivelesApilamientoMax, String idMaquinaria, double capacidadCargaToneladas, double combustibleLitros) {
        super(idMaquinaria, capacidadCargaToneladas, combustibleLitros);
        this.nivelesApilamientoMax = nivelesApilamientoMax;
    }

    public void setNivelesApilamientoMax(int nivelesApilamientoMax) {
        this.nivelesApilamientoMax = nivelesApilamientoMax;
    }

    public int getNivelesApilamientoMax() {
        return nivelesApilamientoMax;
    }

    @Override
    public String toString() {
        return "GruaApiladoraPatio{" + "nivelesApilamientoMax=" + nivelesApilamientoMax + '}';
    }
    
    @Override
    public double CertificarPesoVGM() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String generarTicketTara() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void operarTurno(int horas) {
        super.operarTurno(horas); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    
}
