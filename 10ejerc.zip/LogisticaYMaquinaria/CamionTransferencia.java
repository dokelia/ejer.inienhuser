/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogisticaYMaquinaria;

/**
 *
 * @author ingeb
 */
public class CamionTransferencia extends MaquinariaPortuaria{
    private int velocidadMaxPatioKmH;
    private String tipoEnganchePlataforma;

    public CamionTransferencia() {
    }

    public CamionTransferencia(int velocidadMaxPatioKmH, String tipoEnganchePlataforma, String idMaquinaria, double capacidadCargaToneladas, double combustibleLitros) {
        super(idMaquinaria, capacidadCargaToneladas, combustibleLitros);
        this.velocidadMaxPatioKmH = velocidadMaxPatioKmH;
        this.tipoEnganchePlataforma = tipoEnganchePlataforma;
    }

    public void setVelocidadMaxPatioKmH(int velocidadMaxPatioKmH) {
        this.velocidadMaxPatioKmH = velocidadMaxPatioKmH;
    }

    public void setTipoEnganchePlataforma(String tipoEnganchePlataforma) {
        this.tipoEnganchePlataforma = tipoEnganchePlataforma;
    }

    public int getVelocidadMaxPatioKmH() {
        return velocidadMaxPatioKmH;
    }

    public String getTipoEnganchePlataforma() {
        return tipoEnganchePlataforma;
    }

    @Override
    public String toString() {
        return "CamionTransferencia{" + "velocidadMaxPatioKmH=" + velocidadMaxPatioKmH + ", tipoEnganchePlataforma=" + tipoEnganchePlataforma + '}';
    }

    @Override
    public double CertificarPesoVGM() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String generarTicketTara() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void operarTurno(int horas) {
        super.operarTurno(horas); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    public void acoplarPlataforma(){}
    
}
