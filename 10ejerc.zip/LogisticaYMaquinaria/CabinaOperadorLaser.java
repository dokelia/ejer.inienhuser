/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogisticaYMaquinaria;

/**
 *
 * @author ingeb
 */
public class CabinaOperadorLaser {
    private String modeloGuiadoOptico;
    private boolean resolucionCamaras4K;

    public CabinaOperadorLaser() {
    }

    public CabinaOperadorLaser(String modeloGuiadoOptico, boolean resolucionCamaras4K) {
        this.modeloGuiadoOptico = modeloGuiadoOptico;
        this.resolucionCamaras4K = resolucionCamaras4K;
    }

    public void setModeloGuiadoOptico(String modeloGuiadoOptico) {
        this.modeloGuiadoOptico = modeloGuiadoOptico;
    }

    public void setResolucionCamaras4K(boolean resolucionCamaras4K) {
        this.resolucionCamaras4K = resolucionCamaras4K;
    }

    public String getModeloGuiadoOptico() {
        return modeloGuiadoOptico;
    }

    public boolean isResolucionCamaras4K() {
        return resolucionCamaras4K;
    }

    @Override
    public String toString() {
        return "CabinaOperadorLaser{" + "modeloGuiadoOptico=" + modeloGuiadoOptico + ", resolucionCamaras4K=" + resolucionCamaras4K + '}';
    }
    
    public boolean calibrarAlineacionContenedor(){
        return false;
    }
}
