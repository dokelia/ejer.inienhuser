/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BibliotecaDigital;

/**
 *
 * @author ingeb
 */
public class SoporteTecnico {
    private  String nombreFormato;
    private boolean activo;

    public SoporteTecnico() {
    }

    public SoporteTecnico(String nombreFormato, boolean activo) {
        this.nombreFormato = nombreFormato;
        this.activo = activo;
    }

    public void setNombreFormato(String nombreFormato) {
        this.nombreFormato = nombreFormato;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public String getNombreFormato() {
        return nombreFormato;
    }

    public boolean isActivo() {
        return activo;
    }

    @Override
    public String toString() {
        return "SoporteTecnico{" + "nombreFormato=" + nombreFormato + ", activo=" + activo + '}';
    }
    
}
