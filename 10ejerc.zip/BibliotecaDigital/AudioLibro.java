/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BibliotecaDigital;

/**
 *
 * @author ingeb
 */
public class AudioLibro extends RecursoBiblioteca {
    private double duracionMinutos;
    private SoporteTecnico soporte;

    public AudioLibro() {
    }

    public AudioLibro(double duracionMinutos, SoporteTecnico soporte, String id, String titulo, boolean disponible) {
        super(id, titulo, disponible);
        this.duracionMinutos = duracionMinutos;
        this.soporte = soporte;
    }

    public double getDuracionMinutos() {
        return duracionMinutos;
    }

    public SoporteTecnico getSoporte() {
        return soporte;
    }

    public void setDuracionMinutos(double duracionMinutos) {
        this.duracionMinutos = duracionMinutos;
    }

    public void setSoporte(SoporteTecnico soporte) {
        this.soporte = soporte;
    }

    @Override
    public String toString() {
        return "AudioLibro{" + "duracionMinutos=" + duracionMinutos + ", soporte=" + soporte + '}';
    }

    @Override
    public void descargar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public void reproducirMuestra(){}
    
}
