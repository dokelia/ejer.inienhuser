/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MonitoreoYFumigacion;

/**
 *
 * @author ingeb
 */
public class DronFumigador extends DispositivoAgricola {
    private double caudaLitrosPorMinuto;
    private TanquePresurizadoAgro tanqueQuimico;

    public DronFumigador() {
    }

    public DronFumigador(double caudaLitrosPorMinuto, TanquePresurizadoAgro tanqueQuimico, String idDispositivo, double hectareasCobertura, int bateriaRastante) {
        super(idDispositivo, hectareasCobertura, bateriaRastante);
        this.caudaLitrosPorMinuto = caudaLitrosPorMinuto;
        this.tanqueQuimico = tanqueQuimico;
    }

    public void setCaudaLitrosPorMinuto(double caudaLitrosPorMinuto) {
        this.caudaLitrosPorMinuto = caudaLitrosPorMinuto;
    }

    public void setTanqueQuimico(TanquePresurizadoAgro tanqueQuimico) {
        this.tanqueQuimico = tanqueQuimico;
    }

    public double getCaudaLitrosPorMinuto() {
        return caudaLitrosPorMinuto;
    }

    public TanquePresurizadoAgro getTanqueQuimico() {
        return tanqueQuimico;
    }

    @Override
    public String toString() {
        return "DronFumigador{" + "caudaLitrosPorMinuto=" + caudaLitrosPorMinuto + ", tanqueQuimico=" + tanqueQuimico + '}';
    }
    
    @Override
    public double calcularIndiceVigorVegetal() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String generarMapaEstresHidrico() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void ejecutarCicloLaboral() {
        super.ejecutarCicloLaboral(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    public void iniciarAspersionUniforme(){}
}
