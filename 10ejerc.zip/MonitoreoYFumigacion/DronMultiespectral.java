/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MonitoreoYFumigacion;

/**
 *
 * @author ingeb
 */
public class DronMultiespectral extends DispositivoAgricola{
    private int  bandasEspectrales;

    public DronMultiespectral() {
    }

    public DronMultiespectral(int bandasEspectrales, String idDispositivo, double hectareasCobertura, int bateriaRastante) {
        super(idDispositivo, hectareasCobertura, bateriaRastante);
        this.bandasEspectrales = bandasEspectrales;
    }

    public void setBandasEspectrales(int bandasEspectrales) {
        this.bandasEspectrales = bandasEspectrales;
    }

    public int getBandasEspectrales() {
        return bandasEspectrales;
    }

    @Override
    public String toString() {
        return "DronMultiespectral{" + "bandasEspectrales=" + bandasEspectrales + '}';
    }
    
    @Override
    public double calcularIndiceVigorVegetal() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String generarMapaEstresHidrico() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void ejecutarCicloLaboral() {
        super.ejecutarCicloLaboral(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    
}
