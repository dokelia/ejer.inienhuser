/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MonitoreoYFumigacion;

/**
 *
 * @author ingeb
 */
public abstract class DispositivoAgricola implements IAnalizableNDVI {
    private String idDispositivo;
    private double hectareasCobertura;
    private int bateriaRastante; 

    public DispositivoAgricola() {
    }

    public DispositivoAgricola(String idDispositivo, double hectareasCobertura, int bateriaRastante) {
        this.idDispositivo = idDispositivo;
        this.hectareasCobertura = hectareasCobertura;
        this.bateriaRastante = bateriaRastante;
    }

    public void setIdDispositivo(String idDispositivo) {
        this.idDispositivo = idDispositivo;
    }

    public void setHectareasCobertura(double hectareasCobertura) {
        this.hectareasCobertura = hectareasCobertura;
    }

    public void setBateriaRastante(int bateriaRastante) {
        this.bateriaRastante = bateriaRastante;
    }

    public String getIdDispositivo() {
        return idDispositivo;
    }

    public double getHectareasCobertura() {
        return hectareasCobertura;
    }

    public int getBateriaRastante() {
        return bateriaRastante;
    }

    @Override
    public String toString() {
        return "DispositivoAgricola{" + "idDispositivo=" + idDispositivo + ", hectareasCobertura=" + hectareasCobertura + ", bateriaRastante=" + bateriaRastante + '}';
    }
    
    public void ejecutarCicloLaboral(){}
    public int reportarEstadoBateria(){
        return 0;
    }
}

