/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MonitoreoYFumigacion;

/**
 *
 * @author ingeb
 */
public class EstacionMeteorologicaCampo extends DispositivoAgricola{
    private double sensorPluviometroMm;
    private double presionBarometricaHPa;

    public EstacionMeteorologicaCampo() {
    }

    public EstacionMeteorologicaCampo(double sensorPluviometroMm, double presionBarometricaHPa, String idDispositivo, double hectareasCobertura, int bateriaRastante) {
        super(idDispositivo, hectareasCobertura, bateriaRastante);
        this.sensorPluviometroMm = sensorPluviometroMm;
        this.presionBarometricaHPa = presionBarometricaHPa;
    }

    public void setSensorPluviometroMm(double sensorPluviometroMm) {
        this.sensorPluviometroMm = sensorPluviometroMm;
    }

    public void setPresionBarometricaHPa(double presionBarometricaHPa) {
        this.presionBarometricaHPa = presionBarometricaHPa;
    }

    public double getSensorPluviometroMm() {
        return sensorPluviometroMm;
    }

    public double getPresionBarometricaHPa() {
        return presionBarometricaHPa;
    }

    @Override
    public String toString() {
        return "EstacionMeteorologicaCampo{" + "sensorPluviometroMm=" + sensorPluviometroMm + ", presionBarometricaHPa=" + presionBarometricaHPa + '}';
    }
    
    @Override
    public double calcularIndiceVigorVegetal() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String generarMapaEstresHidrico() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void ejecutarCicloLaboral() {
        super.ejecutarCicloLaboral(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    public boolean predecirRiesgoHelada(){
        return false;
    }
    
}
