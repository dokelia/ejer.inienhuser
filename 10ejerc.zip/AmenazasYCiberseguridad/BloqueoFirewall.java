/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AmenazasYCiberseguridad;

/**
 *
 * @author ingeb
 */
public class BloqueoFirewall extends IncidenteSeguridad {
    private int puertoDestinoBloqueado;
    private String protocoloRed;

    public BloqueoFirewall() {
    }

    public BloqueoFirewall(int puertoDestinoBloqueado, String protocoloRed, String idAlerta, String direccionIPOrigen, String nivelSeveridad) {
        super(idAlerta, direccionIPOrigen, nivelSeveridad);
        this.puertoDestinoBloqueado = puertoDestinoBloqueado;
        this.protocoloRed = protocoloRed;
    }

    public void setPuertoDestinoBloqueado(int puertoDestinoBloqueado) {
        this.puertoDestinoBloqueado = puertoDestinoBloqueado;
    }

    public void setProtocoloRed(String protocoloRed) {
        this.protocoloRed = protocoloRed;
    }

    public int getPuertoDestinoBloqueado() {
        return puertoDestinoBloqueado;
    }

    public String getProtocoloRed() {
        return protocoloRed;
    }

    @Override
    public String toString() {
        return "BloqueoFirewall{" + "puertoDestinoBloqueado=" + puertoDestinoBloqueado + ", protocoloRed=" + protocoloRed + '}';
    }
    
    @Override
    public String exportarFormatoSyslog() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int calcularPuntajeRiesgo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean mitigarAmenaza() {
        return super.mitigarAmenaza(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    public void aislarSubredTemporal(){
        System.out.println("Aislando Subred");
    }
}
