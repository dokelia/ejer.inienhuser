/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AmenazasYCiberseguridad;

/**
 *
 * @author ingeb
 */
public abstract class IncidenteSeguridad implements IAuditableSIEM{
    private String idAlerta;
    private String direccionIPOrigen;
    private String nivelSeveridad;

    public IncidenteSeguridad() {
    }

    public IncidenteSeguridad(String idAlerta, String direccionIPOrigen, String nivelSeveridad) {
        this.idAlerta = idAlerta;
        this.direccionIPOrigen = direccionIPOrigen;
        this.nivelSeveridad = nivelSeveridad;
    }

    public void setIdAlerta(String idAlerta) {
        this.idAlerta = idAlerta;
    }

    public void setDireccionIPOrigen(String direccionIPOrigen) {
        this.direccionIPOrigen = direccionIPOrigen;
    }

    public void setNivelSeveridad(String nivelSeveridad) {
        this.nivelSeveridad = nivelSeveridad;
    }

    public String getIdAlerta() {
        return idAlerta;
    }

    public String getDireccionIPOrigen() {
        return direccionIPOrigen;
    }

    public String getNivelSeveridad() {
        return nivelSeveridad;
    }

    @Override
    public String toString() {
        return "IncidenteSeguridad{" + "idAlerta=" + idAlerta + ", direccionIPOrigen=" + direccionIPOrigen + ", nivelSeveridad=" + nivelSeveridad + '}';
    }
    
    public boolean mitigarAmenaza(){
        return false;
    }
    
    public void registrarBitacoraIncidente(){
        System.out.println("Bitacora");
    }
    
    
}
