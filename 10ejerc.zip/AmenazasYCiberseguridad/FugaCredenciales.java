/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AmenazasYCiberseguridad;

/**
 *
 * @author ingeb
 */
public class FugaCredenciales extends IncidenteSeguridad{
    private int cantidadCuentasComprometidas;

    public FugaCredenciales() {
    }

    public FugaCredenciales(int cantidadCuentasComprometidas, String idAlerta, String direccionIPOrigen, String nivelSeveridad) {
        super(idAlerta, direccionIPOrigen, nivelSeveridad);
        this.cantidadCuentasComprometidas = cantidadCuentasComprometidas;
    }

    public void setCantidadCuentasComprometidas(int cantidadCuentasComprometidas) {
        this.cantidadCuentasComprometidas = cantidadCuentasComprometidas;
    }

    public int getCantidadCuentasComprometidas() {
        return cantidadCuentasComprometidas;
    }

    @Override
    public String toString() {
        return "FugaCredenciales{" + "cantidadCuentasComprometidas=" + cantidadCuentasComprometidas + '}';
    }
    
    @Override
    public String exportarFormatoSyslog() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int calcularPuntajeRiesgo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean mitigarAmenaza() {
        return super.mitigarAmenaza(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
}
