/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package AmenazasYCiberseguridad;

/**
 *
 * @author ingeb
 */
public interface IAuditableSIEM {
    String exportarFormatoSyslog();
    int calcularPuntajeRiesgo();
}