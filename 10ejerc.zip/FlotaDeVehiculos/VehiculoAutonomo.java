/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FlotaDeVehiculos;

/**
 *
 * @author ingeb
 */
public abstract class VehiculoAutonomo implements IRastreableGPS{
    private String vin;
    private double velocidadMax;
    private boolean enRuta;

    public VehiculoAutonomo() {
    }

    public VehiculoAutonomo(String vin, double velocidadMax, boolean enRuta) {
        this.vin = vin;
        this.velocidadMax = velocidadMax;
        this.enRuta = enRuta;
    }

    public String getVin() {
        return vin;
    }

    public double getVelocidadMax() {
        return velocidadMax;
    }

    public boolean isEnRuta() {
        return enRuta;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public void setVelocidadMax(double velocidadMax) {
        this.velocidadMax = velocidadMax;
    }

    public void setEnRuta(boolean enRuta) {
        this.enRuta = enRuta;
    }

    @Override
    public String toString() {
        return "VehiculoAutonomo{" + "vin=" + vin + ", velocidadMax=" + velocidadMax + ", enRuta=" + enRuta + '}';
    }
    
    public void iniciarRuta(String destino){}
    
    public void frenarEmergencia(){}
    
    
}
