/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ExploracionYSondas;

/**
 *
 * @author ingeb
 */
public class BatiscafoProfundo extends SondaMarina{
    private int tripulacionCapacidad;

    public BatiscafoProfundo() {
    }

    public BatiscafoProfundo(int tripulacionCapacidad, String codigoSonda, double profundidadMaximaMetros, double nivelPresionSoportada) {
        super(codigoSonda, profundidadMaximaMetros, nivelPresionSoportada);
        this.tripulacionCapacidad = tripulacionCapacidad;
    }

    public void setTripulacionCapacidad(int tripulacionCapacidad) {
        this.tripulacionCapacidad = tripulacionCapacidad;
    }

    public int getTripulacionCapacidad() {
        return tripulacionCapacidad;
    }

    @Override
    public String toString() {
        return "BatiscafoProfundo{" + "tripulacionCapacidad=" + tripulacionCapacidad + '}';
    }
    
    
    @Override
    public void emitirPulsoSonar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void mepearRelieveMarino() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void sumergir(double profundidad) {
        super.sumergir(profundidad); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    
}
