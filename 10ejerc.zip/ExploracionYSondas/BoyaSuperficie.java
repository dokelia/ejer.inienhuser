/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ExploracionYSondas;

/**
 *
 * @author ingeb
 */
public class BoyaSuperficie extends SondaMarina {
    private boolean panelSolarFlotante;
    private double frecuenciaBalizaKhz;

    public BoyaSuperficie() {
    }

    public BoyaSuperficie(boolean panelSolarFlotante, double frecuenciaBalizaKhz, String codigoSonda, double profundidadMaximaMetros, double nivelPresionSoportada) {
        super(codigoSonda, profundidadMaximaMetros, nivelPresionSoportada);
        this.panelSolarFlotante = panelSolarFlotante;
        this.frecuenciaBalizaKhz = frecuenciaBalizaKhz;
    }

    public void setPanelSolarFlotante(boolean panelSolarFlotante) {
        this.panelSolarFlotante = panelSolarFlotante;
    }

    public void setFrecuenciaBalizaKhz(double frecuenciaBalizaKhz) {
        this.frecuenciaBalizaKhz = frecuenciaBalizaKhz;
    }

    public boolean isPanelSolarFlotante() {
        return panelSolarFlotante;
    }

    public double getFrecuenciaBalizaKhz() {
        return frecuenciaBalizaKhz;
    }

    @Override
    public String toString() {
        return "BoyaSuperficie{" + "panelSolarFlotante=" + panelSolarFlotante + ", frecuenciaBalizaKhz=" + frecuenciaBalizaKhz + '}';
    }

    @Override
    public void emitirPulsoSonar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void mepearRelieveMarino() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void sumergir(double profundidad) {
        super.sumergir(profundidad); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    public void alertarTraficoMaritimo(){}
    
    
    
}
