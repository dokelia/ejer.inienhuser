/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ExploracionYSondas;

/**
 *
 * @author ingeb
 */
public class BrazoRoboticoHidraulico {
    private double fuerzaLevanteKg;
    private int numeroArticulaciones;

    public BrazoRoboticoHidraulico() {
    }

    public BrazoRoboticoHidraulico(double fuerzaLevanteKg, int numeroArticulaciones) {
        this.fuerzaLevanteKg = fuerzaLevanteKg;
        this.numeroArticulaciones = numeroArticulaciones;
    }

    public double getFuerzaLevanteKg() {
        return fuerzaLevanteKg;
    }

    public int getNumeroArticulaciones() {
        return numeroArticulaciones;
    }

    public void setFuerzaLevanteKg(double fuerzaLevanteKg) {
        this.fuerzaLevanteKg = fuerzaLevanteKg;
    }

    public void setNumeroArticulaciones(int numeroArticulaciones) {
        this.numeroArticulaciones = numeroArticulaciones;
    }

    @Override
    public String toString() {
        return "BrazoRoboticoHidraulico{" + "fuerzaLevanteKg=" + fuerzaLevanteKg + ", numeroArticulaciones=" + numeroArticulaciones + '}';
    }
    
    public boolean recolectarMuestraSuelo(){
        return false;
    }
}
