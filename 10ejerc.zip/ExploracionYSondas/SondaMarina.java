/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ExploracionYSondas;

/**
 *
 * @author ingeb
 */
public abstract class SondaMarina implements ITransmitibleSonar {
    private String codigoSonda;
    private double profundidadMaximaMetros;
    private double nivelPresionSoportada;

    public SondaMarina() {
    }

    public SondaMarina(String codigoSonda, double profundidadMaximaMetros, double nivelPresionSoportada) {
        this.codigoSonda = codigoSonda;
        this.profundidadMaximaMetros = profundidadMaximaMetros;
        this.nivelPresionSoportada = nivelPresionSoportada;
    }

    public String getCodigoSonda() {
        return codigoSonda;
    }

    public double getProfundidadMaximaMetros() {
        return profundidadMaximaMetros;
    }

    public double getNivelPresionSoportada() {
        return nivelPresionSoportada;
    }

    public void setCodigoSonda(String codigoSonda) {
        this.codigoSonda = codigoSonda;
    }

    public void setProfundidadMaximaMetros(double profundidadMaximaMetros) {
        this.profundidadMaximaMetros = profundidadMaximaMetros;
    }

    public void setNivelPresionSoportada(double nivelPresionSoportada) {
        this.nivelPresionSoportada = nivelPresionSoportada;
    }

    @Override
    public String toString() {
        return "SondaMarina{" + "codigoSonda=" + codigoSonda + ", profundidadMaximaMetros=" + profundidadMaximaMetros + ", nivelPresionSoportada=" + nivelPresionSoportada + '}';
    }
    
    
     public void sumergir (double profundidad){}
     public double registrarPresion(){
        return 0;
    }
}
