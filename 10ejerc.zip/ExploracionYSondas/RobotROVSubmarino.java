/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ExploracionYSondas;

/**
 *
 * @author ingeb
 */
public class RobotROVSubmarino extends SondaMarina {
    private double longitudCableUmbilical;
    private BrazoRoboticoHidraulico manipulador;

    public RobotROVSubmarino() {
    }

    public RobotROVSubmarino(double longitudCableUmbilical, BrazoRoboticoHidraulico manipulador, String codigoSonda, double profundidadMaximaMetros, double nivelPresionSoportada) {
        super(codigoSonda, profundidadMaximaMetros, nivelPresionSoportada);
        this.longitudCableUmbilical = longitudCableUmbilical;
        this.manipulador = manipulador;
    }

    public void setLongitudCableUmbilical(double longitudCableUmbilical) {
        this.longitudCableUmbilical = longitudCableUmbilical;
    }

    public void setManipulador(BrazoRoboticoHidraulico manipulador) {
        this.manipulador = manipulador;
    }

    public double getLongitudCableUmbilical() {
        return longitudCableUmbilical;
    }

    public BrazoRoboticoHidraulico getManipulador() {
        return manipulador;
    }

    @Override
    public String toString() {
        return "RobotROVSubmarino{" + "longitudCableUmbilical=" + longitudCableUmbilical + ", manipulador=" + manipulador + '}';
    }
    
    @Override
    public void emitirPulsoSonar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void mepearRelieveMarino() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void sumergir(double profundidad) {
        super.sumergir(profundidad); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    public void maniobrarEnGrieta(){}
}
