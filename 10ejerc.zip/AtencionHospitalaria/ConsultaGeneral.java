/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AtencionHospitalaria;

/**
 *
 * @author ingeb
 */
public class ConsultaGeneral extends AtencionMedica {
    private boolean esRevisionRutina;

    public ConsultaGeneral() {
    }

    public ConsultaGeneral(boolean esRevisionRutina, String codigoAtencion, double costoBase) {
        super(codigoAtencion, costoBase);
        this.esRevisionRutina = esRevisionRutina;
    }

    public boolean isEsRevisionRutina() {
        return esRevisionRutina;
    }

    public void setEsRevisionRutina(boolean esRevisionRutina) {
        this.esRevisionRutina = esRevisionRutina;
    }

    @Override
    public String toString() {
        return "ConsultaGeneral{" + "esRevisionRutina=" + esRevisionRutina + '}';
    }
    
    @Override
    public void calcularCostoTotal(){}
    
    public void emitirRecetaMedica(){}

}
