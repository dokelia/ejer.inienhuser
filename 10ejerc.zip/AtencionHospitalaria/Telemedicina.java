/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AtencionHospitalaria;

/**
 *
 * @author ingeb
 */
public class Telemedicina extends AtencionMedica {
    private String plataformaVideo;

    public Telemedicina() {
    }

    public Telemedicina(String plataformaVideo, String codigoAtencion, double costoBase) {
        super(codigoAtencion, costoBase);
        this.plataformaVideo = plataformaVideo;
    }

    public String getPlataformaVideo() {
        return plataformaVideo;
    }

    public void setPlataformaVideo(String plataformaVideo) {
        this.plataformaVideo = plataformaVideo;
    }

    @Override
    public String toString() {
        return "Telemedicina{" + "plataformaVideo=" + plataformaVideo + '}';
    }

    @Override
    public void calcularCostoTotal(){}
    
    @Override
    public void generarFacturaXML(){}
    
    public void enviarPorCorreo(String email){}
}
    
    

